import React, { useState, useEffect } from "react";
import {
  DBButton,
  DBInput,
  DBInfotext,
  DBStack,
} from "@db-ux/react-core-components";

const App = () => {
  const [feedback, setFeedback] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Listener für Nachrichten vom Plugin-Backend (code.ts)
  useEffect(() => {
    window.onmessage = (event) => {
      const { pluginMessage } = event.data;
      if (pluginMessage && pluginMessage.feedback) {
        setFeedback(pluginMessage.feedback);
        setIsLoading(false); // Laden beenden, wenn Feedback kommt
      }
    };
  }, []);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setFeedback(""); // Altes Feedback löschen
    }
  };

  const handleImport = () => {
    if (!file) {
      setFeedback("Please select a SVG file.");
      return;
    }

    setIsLoading(true);
    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result as string;

      if (!result || !result.includes("<svg")) {
        setFeedback("The selected file does not appear to be a valid SVG.");
        setIsLoading(false);
        return;
      }

      // Sende Daten an Figma
      parent.postMessage(
        {
          pluginMessage: {
            type: "import-svg",
            svg: result,
            filename: file.name,
          },
        },
        "*"
      );
    };

    reader.onerror = () => {
      setFeedback("Error reading the SVG file.");
      setIsLoading(false);
    };

    reader.readAsText(file);
  };

  return (
    <div className="p-fix-md flex flex-col gap-fix-md">
      {/* Header Bereich */}
      <header>
        <h1>DB Logo Importer</h1>
        <p className="text-sm">
          Please download the logo svg from the{" "}
          <a
            href="https://marketingportal.extranet.deutschebahn.com/marketingportal/Marke-und-Design/Basiselemente/Logo/Logozusatz-mit-Tool"
            target="_blank"
            rel="noopener noreferrer"
            className="underline"
          >
            Marketingportal
          </a>{" "}
          and read the{" "}
          <a
            href="https://www.figma.com/design/WXIWe7Cj9bKUAanFfMZlUK/feat--initial-design-logo---pulse--1430--1575?node-id=13920-21204"
            rel="noopener noreferrer"
            target="_blank"
            className="underline"
          >
            documentation
          </a>{" "}
          on implementing it in the logo component.
        </p>
      </header>

      {/* Input Sektion */}
      <DBStack>
        <DBInput
          label="Logo SVG auswählen"
          showLabel={false}
          type="file"
          accept="image/svg+xml"
          onChange={handleFileChange}
          className="w-full"
        />

        <DBButton
          icon="upload"
          variant="brand"
          onClick={handleImport}
          disabled={isLoading}
        >
          {isLoading ? "Importing..." : "Import SVG"}
        </DBButton>
      </DBStack>

      {/* Feedback / Status */}
      {feedback && (
        <DBInfotext
          semantic={feedback.includes("Success") ? "successful" : "critical"}
        >
          {feedback}
        </DBInfotext>
      )}
    </div>
  );
};

export default App;
