# SVG to Component Figma Plugin

This plugin creates a Figma component from an SVG, assigns color variables to shapes, and scales it to a defined size.

## Features

- Import SVG files
- Create Figma components
- Assign color variables
- Scale to user-defined size
